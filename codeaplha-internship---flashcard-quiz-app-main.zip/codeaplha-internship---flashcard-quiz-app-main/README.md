# codeaplha-internship-flashcard quiz app
The Folder Contains the task assigned to me by Cognifyz Technologies, The Task completed by me are as follows

Level 1: Task1:

Create a flashcard quiz app for studying. Users can add flashcards with questions and answers, 
then quiz themselves on the material Track and display the quiz scores .
